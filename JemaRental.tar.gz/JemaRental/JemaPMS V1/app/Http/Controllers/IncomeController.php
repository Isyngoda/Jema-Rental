<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Tenant;

use App\Property;

use App\Income;

use App\Transaction;

use DB;

class IncomeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      $incomes = Income::latest()->paginate(6);
       return view('transactions.index',compact('incomes'))
       ->with('i', (request()->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
      $tenant = Tenant::select('id', DB::raw("concat(fname, ' ' , lname) as full_name"))->pluck('full_name' , 'id');

      $property = Property::pluck('propName' , 'id');

      return view('transactions.income.create', compact(['tenant', 'property']));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if(get_class($request))
        {

          request()->validate([
              'tenantId'  => 'required',
              'propertyId'=> 'required',
              'unit'      => 'required',
              'lease'     => 'required',
              'category'  => 'required',
              'transType' => 'required',
              'payDate'   => 'required',
              'startDate' => 'required',
              'endDate'   => 'required',
              'amount'    => 'required',
          ]);

            $property = Property::where('id', $request->propertyId)->update(['status' => 1]); // fetch the required record

            $tenant = Tenant::where('id', $request->tenantId)->update(['status' => 1]); // fetch the required record
        }

        Transaction::create($request->all());
        return redirect()->route('transactions.index')->with('success','Property assigned to Tenant successfully');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
