<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Transaction;

use App\Property;

use App\Tenant;

use DB;

class TransactionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      $transTotal = DB::table('transactions')->sum('amount');

      $incomeTotal = DB::table('transactions')->where('transType', 1)->sum('amount');

      $expenseTotal = DB::table('transactions')->where('transType', 0)->sum('amount');

      $transactions = Transaction::latest()->paginate(6);
       return view('transactions.index',compact(['transactions', 'transTotal', 'incomeTotal', 'expenseTotal']))
       ->with('i', (request()->input('page', 1) - 1) * 5);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
      $tenant = Tenant::select('id', DB::raw("concat(fname, ' ' , lname) as full_name"))->pluck('full_name' , 'id');

      $property = Property::pluck('propName' , 'id');

      return view('transactions.income.create', compact(['tenant', 'property']));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
