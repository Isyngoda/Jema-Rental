<?php $__env->startSection('breadcrumb'); ?>
  
  <a href="<?php echo e(route('properties.index')); ?>">Properties</a>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb2'); ?>
  
  Add Property

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="header">
                        <h4 class="title">Add Property</h4>
                    </div>
                    <div class="content">
                        <?php echo Form::open(array('route' => 'properties.store','method'=>'POST')); ?>


                        <div class="row">
                            <div class="col-md-12">
                                <label><b>General Information</b></label>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-5">
                                <div class="form-group">
                                    <label>Property Name</label>
                                    <?php echo Form::text('propName', null, array('placeholder' => 'Property Name','class' => 'form-control')); ?>

                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Plot No:</label>
                                    <?php echo Form::text('plotNo', null, array('placeholder' => 'Plot No','class' => 'form-control')); ?>

                                </div>
                                
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Block No:</label>
                                    <?php echo Form::text('blokNo', null, array('placeholder' => 'Block No','class' => 'form-control')); ?>

                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Street Address</label>
                                    <?php echo Form::text('street', null, array('placeholder' => 'Street','class' => 'form-control')); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Region / City</label>
                                    <?php echo Form::text('region', null, array('placeholder' => 'Region','class' => 'form-control')); ?>

                                </div>
                            </div>
                        </div>
                        
                        <hr>

                        <div class="row">
                            <div class="col-md-12">
                                <label><b>Property Type</b></label>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-12">
                                <?php echo Form::select('propType', ['Single-Unit' => 'Single-Unit', 'Multi-Unit' => 'Multi-    Unit'],
                                null, array('class'=>'form-control', 'placeholder'=>'Select Category')); ?>

                            </div>
                        </div>
                        
                        <hr>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Market Rent</label>
                                    <?php echo Form::text('rent', null, array('placeholder' => 'Market Rent ex 10,000','class' => 'form-control')); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Property Image</label>
                                    <?php echo Form::file('image', null, array('placeholder' => 'Image','class' => 'form-control')); ?>

                                </div>
                            </div>
                        </div>   

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <?php echo Form::hidden('status', '0'); ?>

                                </div>
                            </div>
                            <div class="col-md-4"></div>
                        </div>
                        <button type="submit" class="btn btn-default btn-fill pull-left">Back</button>
                        <button type="submit" class="btn btn-info btn-fill pull-right">Save</button>
                        <div class="clearfix"></div>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card card-user">
                    <div class="image">
                        <img src="https://ununsplash.imgix.net/photo-1431578500526-4d9613015464?    fit=crop&fm=jpg&h=300&q=75&w=400" alt="..."/>
                    </div>
                    <div class="content">
                        <div class="author">
                            <a href="#">
                                <img class="avatar border-gray" src="../assets/img/property.jpg" alt="..."/>
                                
                            </a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>