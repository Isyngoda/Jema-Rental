<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use Carbon\Carbon;

use App\Property;

use App\Transaction;

use App\Income;

use App\Expense;

class Tenant extends Model
{
     protected $fillable = ['fname', 'sname', 'lname','gender','dob', 'companyName', 'email', 'mobile', 'status'];

     public function getAgeAttribute()
     {
       return Carbon::parse($this->attributes['dob'])->age;
    }

    public function properties()
    {
      return $this->belongsToMany('App\Property');
    }

    public function income()
    {
        return $this->hasMany('Income');
    }

    public function expense()
    {
        return $this->hasMany('App\Expense');
    }

    public function transaction()
    {
        return $this->hasMany('App\Transaction');
    }
}
