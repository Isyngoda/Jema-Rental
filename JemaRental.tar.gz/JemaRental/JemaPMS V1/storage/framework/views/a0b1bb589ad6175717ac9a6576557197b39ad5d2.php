<?php $__env->startSection('content'); ?>
  <div class="content">
      <div class="container-fluid">
          <div class="row">
              <div class="col-md-12">
                  <div class="card">
                      <div class="header">
                          <h4 class="title">Add Expense</h4>
                      </div>
                      <div class="content all-icons">
                          <?php echo Form::open(array('route' => 'expense.store','method'=>'POST')); ?>

                              <div class="row">
                                  <div class="col-md-5">
                                      <div class="form-group">
                                          <label value="tenantId">Payer / Payee</label>
                                          <?php echo Form::select('tenantId', $tenant, null, array('class'=>'form-control', 'placeholder'=>'Select Tenant')); ?>

                                      </div>
                                  </div>
                                  <div class="col-md-4">
                                      <div class="form-group">
                                          <label value="propertyId">Property</label>
                                          <?php echo Form::select('propertyId', $property, null, array('class'=>'form-control', 'placeholder'=>'Select Property')); ?>

                                      </div>
                                  </div>
                                  <div class="col-md-3">
                                      <div class="form-group">
                                          <label>Unit</label>
                                          <?php echo Form::select('unit', ['1' => '1', '2' => '2'], null, array('class'=>'form-control', 'placeholder'=>'Select Unit')); ?>

                                      </div>
                                  </div>
                              </div>

                              <div class="row">
                                  <div class="col-md-12">
                                      <div class="content table-responsive table-full-width">
                                          <table class="table table-hover table-striped">
                                              <thead>
                                                  <th>Paid Date</th>
                                                  <th>Category</th>
                                                  <th>Amount</th>
                                                  <th></th>
                                              </thead>
                                              <tbody>
                                                  <tr>
                                                      <td>
                                                        <?php echo Form::date('payDate', null, array('placeholder' => 'End Date','class' => 'form-control')); ?>

                                                      </td>
                                                      <td>
                                                        <?php echo Form::select('category', ['Plumbing' => 'Plumbing', 'Electricity' => 'Electricity'], null, array('class'=>'form-control', 'placeholder'=>'Select Category')); ?>

                                                      </td>
                                                      <td>
                                                          <?php echo Form::text('amount',  null, array('placeholder' => 'Amount','class' => 'form-control')); ?>

                                                      </td>
                                                      <td>
                                                          <a href="" class="btn btn-danger">X</a>
                                                      </td>
                                                  </tr>
                                              </tbody>
                                          </table>
                                      </div>
                                  </div>
                              </div>
                              <div class="row">
                                  <div class="col-md-12">
                                      <p><a href="">+add new transaction</a></p>
                                  </div>
                              </div>
                              <div class="row">
                                  <div class="font-icon-list col-lg-8 col-md-8 col-sm-8 col-xs-6 col-xs-6"></div>
                                  <div class="font-icon-list col-lg-4 col-md-4 col-sm-4 col-xs-6 col-xs-6">
                                      <div class="font-icon-detail">
                                          <p>Total</p>
                                          <h3>Tsh 1,000,000</h3>
                                      </div>
                                  </div>
                              </div>

                              
                              <button type="submit" class="btn btn-warning btn-fill pull-right">Mark as Paid</button>
                              

                           <div class="clearfix"></div>
                          </form>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>