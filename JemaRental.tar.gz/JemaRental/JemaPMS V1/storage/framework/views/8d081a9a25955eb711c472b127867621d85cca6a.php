<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <link rel="icon" type="image/png" href="<?php echo e(url('assets/img/favicon.ico')); ?>">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

        <title>Jema Rental System</title>

        <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
        <meta name="viewport" content="width=device-width" />


        <!-- Bootstrap core CSS     -->
        <link href="<?php echo e(url('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" />

        <!-- Animation library for notifications   -->
        <link href="<?php echo e(url('assets/css/animate.min.css')); ?>" rel="stylesheet"/>

        <!--  Light Bootstrap Table core CSS    -->
        <link href="<?php echo e(url('assets/css/light-bootstrap-dashboard.css')); ?>" rel="stylesheet"/>


        <!--  CSS for Demo Purpose, don't include it in your project     -->
        <link href="<?php echo e(url('assets/css/demo.css')); ?>" rel="stylesheet" />


        <!--     Fonts and icons     -->
        <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
        <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
        <link href="<?php echo e(url('assets/css/pe-icon-7-stroke.css')); ?>" rel="stylesheet" />
    </head>
    
    <body>

        <div class="wrapper">

            <div class="sidebar" data-color="red" data-image="<?php echo e(url('assets/img/sidebar-5.jpg')); ?>">

                <div class="sidebar-wrapper">

                    <div class="logo">

                        <a href="<?php echo e(route('dashboard')); ?>" class="simple-text"> Jema Rental </a>

                    </div>

                    <ul class="nav">

                        <li class="<?php echo e(active_check('/')); ?>">

                            <a href="<?php echo e(route('dashboard')); ?>">

                                <i class="pe-7s-keypad"></i>

                                <p>Dashboard</p>

                            </a>

                        </li>

                        <li class="<?php echo e(active_check('properties')); ?>">

                            <a href="<?php echo e(route('properties.index')); ?>">

                                <i class="pe-7s-home"></i>

                                <p>Properties</p>

                            </a>

                        </li>

                        <li class="<?php echo e(active_check('tenants')); ?>">

                            <a href="<?php echo e(route('tenants.index')); ?>">

                                <i class="pe-7s-users"></i>

                                <p>Tenants</p>

                            </a>

                        </li>

                        <li class="<?php echo e(active_check('transactions')); ?>">

                            <a href="<?php echo e(route('transactions.index')); ?>">

                                <i class="pe-7s-cash"></i>

                                <p>Accounting</p>

                            </a>

                        </li>

                        <li>

                            <a href="reports/index.html">

                                <i class="pe-7s-graph"></i>

                                <p>Reports</p>

                            </a>

                        </li>

                        <li class="active-pro">
                            <a href="upgrade.html">
                                <i class="pe-7s-config"></i>
                                <p>Settings</p>
                            </a>
                        </li>
                    </ul>

        </div>
    </div>

    <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-left">
                        <ol class="breadcrumb">
                            <li><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                            <li><?php echo $__env->yieldContent('breadcrumb'); ?></li>
                            <li><?php echo $__env->yieldContent('breadcrumb2'); ?></li>
                        </ol>
                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                        <li><img src="<?php echo e(url('assets/img/avater.jpg')); ?>" class="img-responsive avater-img"></li>
                        <li class="dropdown">
                            <a href="" style="text-transform: capitalize;"><span class="hidden-xs"> <?php echo e(Auth::user()->name); ?></span></a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('/logout')); ?>"
                        
                                class="btn btn-default btn-flat"
                                onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
                                Logout
                            </a>
                        
                            <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                                <?php echo e(csrf_field()); ?>

                            </form>    
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <?php echo $__env->yieldContent('content'); ?>

        <footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    
                </nav>
                <p class="copyright pull-right">
                    &copy; 2017 <a href="www.oceaniatz.com">Oceania Co. LTD</a>, made with love for a better web
                </p>
            </div>
        </footer>

    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="<?php echo e(url('assets/js/jquery-1.10.2.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(url('assets/js/bootstrap.min.js')); ?>" type="text/javascript"></script>

    <!--  Checkbox, Radio & Switch Plugins -->
    <script src="<?php echo e(url('assets/js/bootstrap-checkbox-radio-switch.js')); ?>"></script>

    <!--  Charts Plugin -->
    <script src="<?php echo e(url('assets/js/chartist.min.js')); ?>"></script>

    <!--  Notifications Plugin    -->
    <script src="<?php echo e(url('assets/js/bootstrap-notify.js')); ?>"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
    <script src="<?php echo e(url('assets/js/light-bootstrap-dashboard.js')); ?>"></script>

    <!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
    <script src="<?php echo e(url('assets/js/demo.js')); ?>"></script>

</html>
