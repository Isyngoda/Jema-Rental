<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use App\Tenant;

use App\Income;

use App\Expense;

use App\Transaction;

class Property extends Model
{
  protected $fillable = ['propName', 'plotNo', 'blokNo', 'street', 'region', 'propType', 'rent', 'propImage', 'status'  ];

  public function tenants()
    {
      return $this->belongsToMany('App\Tenant');

    }

    public function income()
    {
        return $this->hasMany('App\Income');
    }

    public function expense()
    {
        return $this->hasMany('App\Expense');
    }

    public function transaction()
    {
        return $this->hasMany('App\Transaction');
    }
}
