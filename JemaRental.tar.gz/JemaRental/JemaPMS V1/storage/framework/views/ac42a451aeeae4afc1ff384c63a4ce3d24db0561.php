<?php $__env->startSection('content'); ?>

  <div class="content">
                     <div class="container-fluid">
                         <div class="row">
                             <div class="col-md-12">
                                 <div class="card">
                                     <div class="header">
                                         <div class="col-md-10">
                                             <div class="row">
                                                 <h4 class="title">Add Properties</h4>
                                                 <p class="category">Sub heading goes here</p>
                                             </div>
                                         </div>
                                         <div class="col-md-2">
                                             <a class="btn btn-primary" href="<?php echo e(route('property.create')); ?>">+ Add new property</a>
                                         </div>
                                     </div>
                                     <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <div class="content">
                                         <div class="row">
                                             <!-- Property one -->

                                             <div class="col-md-4" style="margin-top: 15px;">
                                                 <div class="card card-user">
                                                     <div class="image">
                                                         <img src="https://ununsplash.imgix.net/photo-1431578500526-4d9613015464?fit=crop&fm=jpg&h=300&q=75&w=400" alt="..."/>
                                                     </div>
                                                     <div class="content">
                                                         <div class="author">
                                                           <a href="<?php echo e(route('property.show', $property->id)); ?>" title="View Property">
                                                                 <img class="avatar border-gray" src="../assets/img/property.jpg" alt="..."/>

                                                                 <h4 class="title"><?php echo e($property -> propName); ?><br />
                                                                     <small>tagline here</small>
                                                                 </h4>
                                                             </a>
                                                         </div>
                                                         <p class="description text-center">
                                                             Street name<br/>
                                                             <?php echo e($property -> street); ?>, <?php echo e($property -> region); ?>

                                                         </p>
                                                     </div>
                                                     <hr>
                                                     <div class="text-center">
                                                         <button href="#" class="btn btn-simple">
                                                             <i class="fa fa-users"></i> Tenants
                                                         </button>
                                                         <button href="#" class="btn btn-simple">
                                                             <i class="fa fa-dollar"></i> Accounting
                                                         </button>
                                                     </div>
                                                 </div>
                                             </div>
                                             <!-- / -->
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         </div>
                                     </div>

                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>