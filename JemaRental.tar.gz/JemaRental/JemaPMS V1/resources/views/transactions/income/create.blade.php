@extends('layouts.header')

@section('breadcrumb')

  <a href="{{route('transactions.index')}}">Accointing</a>

@stop

@section('breadcrumb2')

  Add Income

@stop

@section('content')
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title">Add Income</h4>
                    </div>
                    <div class="content all-icons">
                        {!! Form::open(array('route' => 'incomes.store','method'=>'POST')) !!}
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label value="tenantId">Payer / Payee</label>
                                    {!!Form::select('tenantId', $tenant, null, array('class'=>'form-control', 'placeholder'=>'Select Tenant'))!!}
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label value="propertyId">Property</label>
                                    {!!Form::select('propertyId', $property, null, array('class'=>'form-control', 'placeholder'=>'Select Property'))!!}
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label>Unit</label>
                                    {!!Form::select('unit', ['1' => '1', '2' => '2'], null, array('class'=>'form-control', 'placeholder'=>'Select Unit'))!!}
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Lease</label>
                                    {!!Form::select('lease', ['1 Month' => '1 Month', '2 Month' => '2 Month'], null, array('class'=>'form-control', 'placeholder'=>'Select Category'))!!}
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="content table-responsive table-full-width">
                                    <table class="table table-hover table-striped">
                                        <thead>
                                            <th>Start</th>
                                            <th>End Date</th>
                                            <th>Category</th>
                                            <th>Amount</th>
                                            <th>Paid Date</th>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>
                                                    {!! Form::date('startDate', null, array('placeholder' => 'Start Date','class' => 'form-control')) !!}
                                                </td>
                                                <td>
                                                    {!! Form::date('endDate', null, array('placeholder' => 'End Date','class' => 'form-control')) !!}
                                                </td>
                                                <td>
                                                    {!!Form::select('category', ['Rent' => 'Rent', 'Penalty' => 'Penalty'], null, array('class'=>'form-control', 'placeholder'=>'Select Category'))!!}
                                                </td>
                                                <td>
                                                    {!! Form::text('amount',  null, array('placeholder' => 'Amount','class' => 'form-control')) !!}
                                                </td>
                                                <td>
                                                    {!! Form::date('payDate', null, array('placeholder' => 'Pay Date','class' => 'form-control')) !!}
                                                </td>
                                                <td>
                                                    {!! Form::hidden('transType', '1') !!}
                                                </td>

                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <input type="submit" class="btn btn-warning btn-fill pull-right">Mark as Paid</button>
                        <div class="clearfix"></div>
                        {!! Form::close()!!}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
