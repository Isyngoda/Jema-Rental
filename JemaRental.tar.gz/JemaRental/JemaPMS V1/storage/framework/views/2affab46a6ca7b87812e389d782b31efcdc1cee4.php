<?php $__env->startSection('breadcrumb'); ?>

  <a href="<?php echo e(route('transactions.index')); ?>">Accointing</a>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb2'); ?>

  Add Income

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title">Add Income</h4>
                    </div>
                    <div class="content all-icons">
                        <?php echo Form::open(array('route' => 'incomes.store','method'=>'POST')); ?>

                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label value="tenantId">Payer / Payee</label>
                                    <?php echo Form::select('tenantId', $tenant, null, array('class'=>'form-control', 'placeholder'=>'Select Tenant')); ?>

                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label value="propertyId">Property</label>
                                    <?php echo Form::select('propertyId', $property, null, array('class'=>'form-control', 'placeholder'=>'Select Property')); ?>

                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label>Unit</label>
                                    <?php echo Form::select('unit', ['1' => '1', '2' => '2'], null, array('class'=>'form-control', 'placeholder'=>'Select Unit')); ?>

                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Lease</label>
                                    <?php echo Form::select('lease', ['1 Month' => '1 Month', '2 Month' => '2 Month'], null, array('class'=>'form-control', 'placeholder'=>'Select Category')); ?>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="content table-responsive table-full-width">
                                    <table class="table table-hover table-striped">
                                        <thead>
                                            <th>Start</th>
                                            <th>End Date</th>
                                            <th>Category</th>
                                            <th>Amount</th>
                                            <th>Paid Date</th>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <?php echo Form::date('startDate', null, array('placeholder' => 'Start Date','class' => 'form-control')); ?>

                                                </td>
                                                <td>
                                                    <?php echo Form::date('endDate', null, array('placeholder' => 'End Date','class' => 'form-control')); ?>

                                                </td>
                                                <td>
                                                    <?php echo Form::select('category', ['Rent' => 'Rent', 'Penalty' => 'Penalty'], null, array('class'=>'form-control', 'placeholder'=>'Select Category')); ?>

                                                </td>
                                                <td>
                                                    <?php echo Form::text('amount',  null, array('placeholder' => 'Amount','class' => 'form-control')); ?>

                                                </td>
                                                <td>
                                                    <?php echo Form::date('payDate', null, array('placeholder' => 'Pay Date','class' => 'form-control')); ?>

                                                </td>
                                                <td>
                                                    <?php echo Form::hidden('transType', '1'); ?>

                                                </td>

                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <input type="submit" class="btn btn-warning btn-fill pull-right">Mark as Paid</button>
                        <div class="clearfix"></div>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>