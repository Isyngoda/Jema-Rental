<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PropTenant extends Model
{

  public function properties()
  {
  return $this->belongsToMany('App\Property')->withPivot('propId');
  }

  public function tenants()
  {
    return $this->belongsToMany('App\Tenant')->withPivot('tenantId');
  }
}
